﻿using System;

namespace Testat1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Exercise1.Solve();
            Exercise2.Solve();
            Exercise3.Solve();
            Exercise4.Solve();
            Exercise5.Solve();
            Exercise6.Solve();
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Testat1
{
    public static class Exercise4
    {
        public static void Solve()
        {
            Console.WriteLine("----------Start Exercise 4-----------");
            
            Console.WriteLine("Complexity class of Fibonacci iterativ = O(N);");
            Console.WriteLine("Complexity class of Fibonacci rekursiv = O(2^n);");
            Console.WriteLine("Complexity class of Towers of Hanoi = O(2^n);");

            Console.WriteLine("----------Finished Exercise 4-----------");
        }
    }
}
